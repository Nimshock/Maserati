<?php

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}
?>


<!-- CONTENEDOR SECCIÓN DE CONTACTO -->
<div id="contactos" class="contact">
    <div class="section fourth-section">
        <div class="container">
            <div class="title">
                <h1>Contáctanos</h1>
                <p>Conecte con la excelencia: estamos aquí para responder a sus preguntas y ayudarle a vivir la experiencia Maserati.</p>
            </div>

            <!-- CONTENEDOR DE MAPA -->
            <div class="row-fluid">
                <div class="span10 centered">
                    <div id="leaflet-map" style="margin-left: 10%;"></div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- FIN CONTENEDOR DE MAPA -->
