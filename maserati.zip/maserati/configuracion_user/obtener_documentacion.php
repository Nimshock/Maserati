<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: ../login.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $apellido1 = $_POST['apellido1'];
    $apellido2 = $_POST['apellido2'];
    $edad = $_POST['edad'];
    $usuario_id = $_SESSION['id'];

    if ($edad < 18) {
        $_SESSION['error_edad'] = "Debes ser mayor de 18 años para poder registrar la documentación.";
        header("location: obtener_documentacion.php");
        exit();
    }

    $conn->begin_transaction();
    try {
        $sql = "INSERT INTO documentacion (nombre, apellido1, apellido2, edad, usuario_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssii", $nombre, $apellido1, $apellido2, $edad, $usuario_id);

        if ($stmt->execute()) {
            $update_sql = "UPDATE usuarios SET documentado = 1 WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("i", $usuario_id);
            if ($update_stmt->execute()) {
                $conn->commit();
                header("location: documentacion.php?create=success");
                exit();
            } else {
                throw new Exception("No se pudo actualizar el estado del usuario.");
            }
        } else {
            throw new Exception("No se pudo insertar la documentación.");
        }
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_general'] = "Ocurrió un error al procesar tu solicitud. Inténtalo de nuevo.";
        header("location: obtener_documentacion.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" href="../assets/images/logos-image/logoMaseratiDorado.png">
    <title>Crear Documentación - Maserati</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">

    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="../index.php">Maserati&nbsp;&nbsp;<img src="../assets/images/logos-image/logoMaserati2.png"width="15%" /></a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i>&nbsp;Cuenta</a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="configuracion.php">Configuración</a></li>
                    <li><hr class="dropdown-divider" /></li>
                    <li><a class="dropdown-item" href="../logout.php">Cerrar sesión</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Principal</div>
                        <a class="nav-link" href="configuracion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                            Inicio
                        </a>
                        <a class="nav-link" href="documentacion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                            Documentación
                        </a>
                        <a class="nav-link" href="mis_reservas.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-car"></i></div>
                            Mis reservas
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">En sesión como: <br><?php echo htmlspecialchars($_SESSION['usuario']); ?></div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Documentación Maserati</h3></div>
                                    <div class="card-body">
                                        <?php if (isset($_SESSION['error_edad'])): ?>
                                            <div class="alert alert-danger" role="alert">
                                                <?php echo $_SESSION['error_edad']; unset($_SESSION['error_edad']); ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (isset($_SESSION['error_general'])): ?>
                                            <div class="alert alert-danger" role="alert">
                                                <?php echo $_SESSION['error_general']; unset($_SESSION['error_general']);?>
                                            </div>
                                        <?php endif; ?>

                                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputNombre" name="nombre" type="text" placeholder="Nombre" required />
                                                <label for="inputNombre">Nombre</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputApellido1" name="apellido1" type="text" placeholder="Primer apellido" required />
                                                <label for="inputApellido1">Primer apellido</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputApellido2" name="apellido2" type="text" placeholder="Segundo apellido" required />
                                                <label for="inputApellido2">Segundo apellido</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputEdad" name="edad" type="number" placeholder="Edad" required min="18"/>
                                                <label for="inputEdad">Edad</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <button class="btn btn-primary" type="submit">Registrar documentación</button>
                                                <a href="configuracion.php" class="btn btn-secondary">Volver</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
            </main>
            
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Cosmin - Maserati 2025</div>

                        <div class="redes">
                            <a href="https://x.com/?lang=es" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/twitterx.svg" type="" width="30px" height="30px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.instagram.com/" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/instagram.svg" type="" width="35px" height="35px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.facebook.com/?locale=es_ES" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/facebook.svg" type="" width="35px" height="35px"></object></a>
                        </div>


                        <div>
                            <i class="fas fa-phone-alt"></i>
                            <span>+34 642 74 02 39</span>
                        </div>

                        <div>
                            <a href="accesibilidad.php">Accesibilidad</a>
                            &middot;
                            <a href="politica_privacidad.php">Política de Privacidad</a>
                            &middot;
                            <a href="politica_cookies.php">Política de Cookies</a>
                            &middot;
                            <a href="terminos.php">Términos &amp; condiciones de uso</a>
                        </div>
                    </div>
                </div>
            </footer>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../assets/js/scripts.js"></script>
</body>
</html>