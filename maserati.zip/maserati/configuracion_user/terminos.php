<?php
session_start();

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: ../login.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" href="../assets/images/logos-image/logoMaseratiDorado.png" type="">
    <title>Aviso Legal - Maserati</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        .card-body {
        margin-left: 20px;
        margin-right: 20px;
        padding: 20px;
        max-width: 800px;
        text-align: justify;
        }
        .card{
            margin-left:20%;
            margin-right:20%;
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="../index.php">Maserati&nbsp;&nbsp;<img src="../assets/images/logos-image/logoMaserati2.png"width="15%" /></a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i>&nbsp;Cuenta</a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="configuracion.php">Configuración</a></li>
                    <li><hr class="dropdown-divider" /></li>
                    <li><a class="dropdown-item" href="../logout.php">Cerrar sesión</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Principal</div>
                        <a class="nav-link" href="configuracion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                            Configuración
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">En sesión como: <br><?php echo $_SESSION['usuario']; ?></div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
            <div id="cookieConsent" class="alert alert-info alert-dismissible fade show" role="alert" style="display: none;">
                <strong>Este sitio web utiliza cookies analíticas para analizar tus hábitos de navegación y aprender a mejorar para garantizar la mejor experiencia en nuestro sitio web.<br>
                Toda la información recopilada es no confidencial, además puede comprobar qué información se recopila en nuestra <a href="politica_cookies.php">Política de Cookies</a>.
                <br>Al hacer clic en Aceptar, aceptas el uso de las cookies analíticas.<br><br></strong>
                <button type="button" class="btn btn-primary btn-sm" id="btnAccept">Aceptar</button>
                <button type="button" class="btn btn-primary btn-sm" id="btnReject">Rechazar</button>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Maserati</h1>
                    <ol class="breadcrumb mb-4">
                        <i class="fas fa-gavel"></i>&nbsp;
                        <li class="breadcrumb-item active">Terminos & Condiciones de Uso y Aviso Legal</li>
                    </ol>
                    <div class="row">
                        <div class="col-12">
                            <div class="card mb-4">
                                <div class="card-body text-justify mx-auto">
                                    <strong>Información general</strong>
                                    <p>El titular de este sitio web es Maserati, con NIF B-41856823, y domicilio situado en C. del Conde de Aranda, 9, Casco Antiguo, 50004 Zaragoza (Zaragoza).
                                    Inscrito en el Registro Mercantil de Zaragoza. Puedes contactar con Maserati por medio de telefonía:<br>642 74 02 39.</p>

                                    <strong>Contenidos</strong>
                                    <p>El presente sitio web tiene un carácter meramente informativo, no constituyendo en ningún caso un medio de asesoramiento sobre ninguna de las áreas específicadas en el mismo,
                                    para lo cual el usuario deberá dirigirse al titular del sitio web.</p>
                                    <p>La información incluída en el sitio web ha seguido los requerimientos pedidos por la Ley, pero de ninguna forma eso implica que tenga que estar necesariamente detallada, completa,
                                    exacta o mantenerse actualizada, debido en su caso a las variaciones que puedan producirse en la normativa, jurisprudencia u otros documentos de interés considerados.</p>
                                    <p>La utilización de la información proporcionada a través de este sitio web es responsabilidad exclusiva del usuario, no siendo Maserati en ningún caso responsable de los errores u
                                    omisiones que pudieran existir así como de la aplicación o uso concreto que pueda hacerse de la misma.</p>

                                    <strong>Propiedad Intelectual</strong>
                                    <p>Los contenidos que figuran en este sitio web están sujetos a derechos de autor, no permitiendo la reproducción de los mismos, salvo autorización previa del titular Maserati. La información
                                    de terceros que pudiera incluirse aquí está sujeta a los correspondientes avisos sobre derechos de propiedad intelectual correspondientes a los mismos. Maserati es una firma registrada cuya
                                    utilización está absolutamente prohibida.</p>

                                    <strong>Enlaces</strong>
                                    <p>Maserati no asume ninguna responsabilidad sobre los enlaces hacia otros sitios o páginas web que, en su caso, pudieran incluirse en el mismo, ya que no tiene ningún tipo de control sobre los
                                    mismos, por lo que el usuario accede bajo su exclusiva responsabilidad al contenido y en las condiciones de uso que rijan en los mismos.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <!-- FOOTER -->
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Cosmin - Maserati 2025</div>

                        <div class="redes">
                            <a href="https://x.com/?lang=es" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/twitterx.svg" type="" width="30px" height="30px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.instagram.com/" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/instagram.svg" type="" width="35px" height="35px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.facebook.com/?locale=es_ES" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/facebook.svg" type="" width="35px" height="35px"></object></a>
                        </div>

                        <!-- TELÉFONO -->
                        <div>
                            <i class="fas fa-phone-alt"></i>
                            <span>+34 642 74 02 39</span>
                        </div>

                        <div>
                            <a href="accesibilidad.php">Accesibilidad</a>
                            &middot;
                            <a href="politica_privacidad.php">Política de Privacidad</a>
                            &middot;
                            <a href="politica_cookies.php">Política de Cookies</a>
                            &middot;
                            <a href="terminos.php">Términos &amp; condiciones de uso</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script>
        function getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return parts.pop().split(';').shift();
        }
        function setCookie(name, value) {
            const now = new Date();
            const yearLater = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
            document.cookie = `${name}=${value}; expires=${yearLater.toUTCString()}; path=/`;
        }
        function showCookieConsent() {
            if (!getCookie('cookieAnalitica')) {
                document.getElementById('cookieConsent').style.display = 'block';
            }
        }
        document.getElementById('btnAccept').addEventListener('click', function() {
            setCookie('cookieAnalitica', 'aceptado');
            document.getElementById('cookieConsent').style.display = 'none';
        });
        document.getElementById('btnReject').addEventListener('click', function() {
            document.getElementById('cookieConsent').style.display = 'none';
        });
        window.addEventListener('load', showCookieConsent);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../assets/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="../assets/js/datatables-simple-demo.js"></script>
</body>
</html>