<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: ../login.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

$usuario_id = $_SESSION['id'];


$conn->begin_transaction();

try {

    $sql_delete = "DELETE FROM documentacion WHERE usuario_id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $usuario_id);
    $stmt_delete->execute();
    $stmt_delete->close();


    $sql_update = "UPDATE usuarios SET documentado = 0 WHERE id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("i", $usuario_id);
    $stmt_update->execute();
    $stmt_update->close();

    $conn->commit();


    header("location: configuracion.php?delete_doc=success");
    exit;

} catch (Exception $e) {

    $conn->rollback();

    header("location: documentacion.php?error=true");
    exit;
}

$conn->close();
?>