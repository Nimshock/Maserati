<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: ../login.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password === $confirm_password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $query_update_password = "UPDATE usuarios SET contrasena = ? WHERE id = ?";
        $stmt_update_password = $conn->prepare($query_update_password);
        $stmt_update_password->bind_param("si", $hashed_password, $_SESSION['id']);
        
        if ($stmt_update_password->execute()) {
            $_SESSION['password_updated'] = true;
            $stmt_update_password->close();
        } else {
            $_SESSION['password_update_error'] = "Error al actualizar la contraseña. Por favor, inténtalo de nuevo más tarde.";
        }
    } else {
        $_SESSION['password_update_error'] = "Las contraseñas no coinciden. Por favor, inténtalo de nuevo.";
    }

    header("location: configuracion.php");
    exit();
}

$stmt = $conn->prepare("SELECT id, usuario, role, created_at, documentado FROM usuarios WHERE usuario = ?");
$stmt->bind_param("s", $_SESSION['usuario']);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($id, $usuario, $role, $created_at, $documentado);
    $stmt->fetch();
    $_SESSION['id'] = $id;
    $_SESSION['created_at'] = $created_at;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" href="../assets/images/logos-image/logoMaseratiDorado.png" type="">
    <title>Usuario - Maserati</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        .card-body {
            margin-left: 20px;
            margin-right: 20px;
            padding: 20px;
            max-width: 800px;
            text-align: justify;
        }

        .card {
            margin-left: 20%;
            margin-right: 20%;
        }

        .form-control[readonly] {
            background-color: #f5f5f5;
        }
    </style>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="../index.php">Maserati&nbsp;&nbsp;<img src="../assets/images/logos-image/logoMaserati2.png"width="15%" /></a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i
                class="fas fa-bars"></i></button>
        <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown"
                    aria-expanded="false"><i class="fas fa-user fa-fw"></i>&nbsp;Cuenta</a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="../index.php">Volver a Inicio</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="../logout.php">Cerrar sesión</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Principal</div>
                        <a class="nav-link" href="configuracion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                            Inicio
                        </a>
                        <a class="nav-link" href="documentacion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                            Documentación
                        </a>
                        <a class="nav-link" href="mis_reservas.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-car"></i></div>
                            Mis reservas
                        </a>
                    </div>
                </div>
                <div class="small" style="position: relative; bottom: 1%;">&nbsp;Miembro de Maserati desde:
                    &nbsp;<?php echo date('d/m/Y', strtotime($_SESSION['created_at'])); ?></div>
                <div class="sb-sidenav-footer">
                    <div class="small">En sesión como: <br><?php echo $_SESSION['usuario']; ?></div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div id="cookieConsent" class="alert alert-info alert-dismissible fade show" role="alert"
                    style="display: none;">
                    <strong>Este sitio web utiliza cookies analíticas para analizar tus hábitos de navegación y aprender
                        a mejorar para garantizar la mejor experiencia en nuestro sitio web.<br>
                        Toda la información recopilada es no confidencial, además puede comprobar qué información se
                        recopila en nuestra <a href="politica_cookies.php">Política de Cookies</a>.
                        <br>Al hacer clic en Aceptar, aceptas el uso de las cookies analíticas.<br><br></strong>
                    <button type="button" class="btn btn-primary btn-sm" id="btnAccept">Aceptar</button>
                    <button type="button" class="btn btn-primary btn-sm" id="btnReject">Rechazar</button>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <div class="container-fluid px-4">
                    <br><br><br><br>
                    <div class="row">
                        <div class="col-6">
                            <div class="card mb-4">
                                <div class="card-body text-justify mx-auto">
                                    <?php if (isset($_SESSION['update_success'])): ?>
                                        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                                            ¡Nombre de usuario actualizado con éxito!
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                        <?php unset($_SESSION['update_success']); ?>
                                    <?php endif; ?>
                                    <?php if (isset($_SESSION['update_error'])): ?>
                                        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                                            <?php echo $_SESSION['update_error']; ?>
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                        <?php unset($_SESSION['update_error']); ?>
                                    <?php endif; ?>
                                    <form method="post" action="update_usuarios.php" id="formGuardaCambios">
                                        <fieldset>
                                            <legend>Modificar nombre de usuario</legend>
                                            <hr>
                                            <input type="hidden" name="id" value="<?php echo $_SESSION['id']; ?>">
                                            <div class="mb-3">
                                                <label for="usuario" class="form-label">Nombre de usuario</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" id="usuario" name="usuario"
                                                        value="<?php echo htmlspecialchars($usuario); ?>" readonly>
                                                    <button type="button" class="btn btn-primary"
                                                        id="editarUsuario">Editar</button>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="documentado" class="form-label">Documentación Maserati:</label>
                                                <?php if ($documentado == 0): ?>
                                                    <a href="obtener_documentacion.php" style="text-decoration: none; color: #800000;"><br>
                                                    <u>¡Crea ya tu documentación Maserati!</u></a>
                                                <?php endif; ?>
                                            </div>
                                            <button type="submit" class="btn btn-success">Guardar cambios</button>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <div class="col-6">
                            <div class="card mb-4">
                                <div class="card-body text-justify mx-auto">
                                    <?php if (isset($_SESSION['password_updated'])): ?>
                                        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                                            ¡Contraseña actualizada con éxito!
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>


                                    <?php unset($_SESSION['password_updated']); ?>
                                    <?php elseif (isset($_SESSION['password_update_error'])): ?>
                                        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                                            <?php echo $_SESSION['password_update_error']; ?>
                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                        <?php unset($_SESSION['password_update_error']); ?>
                                    <?php endif; ?>


                                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                        <fieldset>
                                            <legend>Modificar contraseña</legend>
                                            <hr>
                                            <div class="mb-3">
                                                <label for="password" class="form-label">Nueva Contraseña</label>
                                                <input type="password" class="form-control" id="password"
                                                    name="password" placeholder="Escribe la nueva" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="confirm_password" class="form-label">Confirmar
                                                    Contraseña</label>
                                                <input type="password" class="form-control" id="confirm_password"
                                                    name="confirm_password" placeholder="Repite la contraseña" required>
                                            </div>
                                            <button type="submit" name="change_password" class="btn btn-success">Cambiar
                                                Contraseña</button>
                                        </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>


            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Cosmin - Maserati 2025</div>

                        <div class="redes">
                            <a href="https://x.com/?lang=es" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/twitterx.svg" type="" width="30px" height="30px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.instagram.com/" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/instagram.svg" type="" width="35px" height="35px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.facebook.com/?locale=es_ES" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/facebook.svg" type="" width="35px" height="35px"></object></a>
                        </div>

                        <div>
                            <i class="fas fa-phone-alt"></i>
                            <span>+34 642 74 02 39</span>
                        </div>

                        <div>
                            <a href="accesibilidad.php">Accesibilidad</a>
                            &middot;
                            <a href="politica_privacidad.php">Política de Privacidad</a>
                            &middot;
                            <a href="politica_cookies.php">Política de Cookies</a>
                            &middot;
                            <a href="terminos.php">Términos &amp; condiciones de uso</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

<?php include("scripts_2.php")?>
<script src="../assets/js/scripts.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>


<script>
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
    }
    function setCookie(name, value) {
        const now = new Date();
        const yearLater = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
        document.cookie = `<span class="math-inline">\{name\}\=</span>{value}; expires=${yearLater.toUTCString()}; path=/`;
    }
    function showCookieConsent() {
        if (!getCookie('cookieAnalitica')) {
            document.getElementById('cookieConsent').style.display = 'block';
        }
    }
    document.getElementById('btnAccept').addEventListener('click', function() {
        setCookie('cookieAnalitica', 'aceptado');
        document.getElementById('cookieConsent').style.display = 'none';
    });
    document.getElementById('btnReject').addEventListener('click', function() {
        document.getElementById('cookieConsent').style.display = 'none';
    });
    window.addEventListener('load', showCookieConsent);


    document.getElementById('editarUsuario').addEventListener('click', function () {
        document.getElementById('usuario').readOnly = false;
    });


    document.getElementById('formGuardaCambios').addEventListener('submit', function (event) {
        var confirmacion = confirm("¿Estás seguro de guardar los cambios?");
        if (!confirmacion) {
            event.preventDefault();
        }
    });
</script>
</body>
</html>