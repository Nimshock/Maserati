<?php
session_start();


if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: ../login.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: mis_reservas.php");
    exit;
}

$reserva_id = $_GET['id'];
$usuario_id = $_SESSION['id'];


$sql = "DELETE FROM reservas WHERE id = ? AND usuario_id = ?";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("ii", $reserva_id, $usuario_id);
    
    if ($stmt->execute()) {
        header("location: mis_reservas.php?delete=success");
    } else {
        header("location: mis_reservas.php?error=delete_failed");
    }
    $stmt->close();
}
$conn->close();
?>