<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: ../login.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

$usuario_id = $_SESSION['id'];

$documentacion_encontrada = false;


$nombre = '';
$apellido1 = '';
$apellido2 = '';
$edad = '';
$error_message = '';


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $nombre_post = $_POST['nombre'];
    $apellido1_post = $_POST['apellido1'];
    $apellido2_post = $_POST['apellido2'];
    $edad_post = $_POST['edad'];

    if ($edad_post < 18) {
        $error_message = "Error: La edad no puede ser menor de 18 años.";
    } else {
        $query_update = "UPDATE documentacion SET nombre = ?, apellido1 = ?, apellido2 = ?, edad = ? WHERE usuario_id = ?";
        $stmt_update = $conn->prepare($query_update);
        $stmt_update->bind_param("sssii", $nombre_post, $apellido1_post, $apellido2_post, $edad_post, $usuario_id);

        if ($stmt_update->execute()) {
            header("location: documentacion.php?edit=success");
            exit;
        } else {
            $error_message = "Error al actualizar los datos: " . $stmt_update->error;
        }
        $stmt_update->close();
    }
}


$query_check = "SELECT documentado FROM usuarios WHERE id = ?";
$stmt_check = $conn->prepare($query_check);
$stmt_check->bind_param("i", $usuario_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    $user_status = $result_check->fetch_assoc();
    if ($user_status['documentado'] == 0) {
    }
}
$stmt_check->close();


$query_data = "SELECT nombre, apellido1, apellido2, edad FROM documentacion WHERE usuario_id = ?";
$stmt_data = $conn->prepare($query_data);
$stmt_data->bind_param("i", $usuario_id);
$stmt_data->execute();
$result_data = $stmt_data->get_result();

if ($result_data->num_rows > 0) {
    $documentacion_encontrada = true;
    $doc_data = $result_data->fetch_assoc();
    $nombre = $doc_data['nombre'];
    $apellido1 = $doc_data['apellido1'];
    $apellido2 = $doc_data['apellido2'];
    $edad = $doc_data['edad'];
}
$stmt_data->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" href="../assets/images/logos-image/logoMaseratiDorado.png">
    <title>Documentación - Maserati</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="../index.php">Maserati&nbsp;&nbsp;<img
                src="../assets/images/logos-image/logoMaserati2.png" width="15%" /></a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i
                class="fas fa-bars"></i></button>
        <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown"
                    aria-expanded="false"><i class="fas fa-user fa-fw"></i>&nbsp;Cuenta</a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="configuracion.php">Configuración</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="../logout.php">Cerrar sesión</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Principal</div>
                        <a class="nav-link" href="configuracion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                            Inicio
                        </a>
                        <a class="nav-link active" href="documentacion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-file"></i></div>
                            Documentación
                        </a>
                        <a class="nav-link" href="mis_reservas.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-car"></i></div>
                            Mis reservas
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">En sesión como: <br><?php echo htmlspecialchars($_SESSION['usuario']); ?></div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Mi Documentación</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item">Cuenta / Mi documentación</li>
                    </ol>

                    <?php if (isset($_GET['edit']) && $_GET['edit'] == 'success'): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            ¡Datos actualizados correctamente!
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger" role="alert"><?php echo $error_message; ?></div>
                    <?php endif; ?>

                    <?php if ($documentacion_encontrada): ?>

                        <div id="documentData" class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-file"></i>
                                <strong>Documentación Maserati</strong>
                                <a href="borrar_mi_documentacion.php" class="btn btn-sm btn-outline-danger float-end ms-2"
                                    onclick="return confirm('¿Estás seguro de que quieres borrar tu documentación? Esta acción no se puede deshacer.');">
                                    Borrar
                                </a>
                                <button class="btn btn-sm btn-outline-primary float-end"
                                    onclick="enableEdit()">Editar</button>
                            </div>
                            <div class="card-body">
                                <p><strong>Nombre:</strong> <?php echo htmlspecialchars($nombre); ?></p>
                                <p><strong>Primer apellido:</strong> <?php echo htmlspecialchars($apellido1); ?></p>
                                <p><strong>Segundo apellido:</strong> <?php echo htmlspecialchars($apellido2); ?></p>
                                <p><strong>Edad:</strong> <?php echo htmlspecialchars($edad); ?></p>
                            </div>
                        </div>

                        <div id="editForm" style="display: none;" class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-edit"></i>
                                <strong>Editando Documentación</strong>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                    <div class="mb-3">
                                        <label for="nombre_edit" class="form-label">Nombre</label>
                                        <input type="text" class="form-control" id="nombre_edit" name="nombre"
                                            value="<?php echo htmlspecialchars($nombre); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="apellido1_edit" class="form-label">Primer Apellido</label>
                                        <input type="text" class="form-control" id="apellido1_edit" name="apellido1"
                                            value="<?php echo htmlspecialchars($apellido1); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="apellido2_edit" class="form-label">Segundo Apellido</label>
                                        <input type="text" class="form-control" id="apellido2_edit" name="apellido2"
                                            value="<?php echo htmlspecialchars($apellido2); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="edad_edit" class="form-label">Edad</label>
                                        <input type="number" class="form-control" id="edad_edit" name="edad"
                                            value="<?php echo htmlspecialchars($edad); ?>" required min="18">
                                    </div>
                                    <button type="submit" class="btn btn-primary" name="submit">Guardar Cambios</button>
                                    <button type="button" class="btn btn-secondary" onclick="cancelEdit()">Cancelar</button>
                                </form>
                            </div>
                        </div>

                    <?php else: ?>

                        <div class="card text-center">
                            <div class="card-header">
                                Documentación Pendiente
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Aún no has creado tu documentación</h5>
                                <p class="card-text">Es necesario para poder reservar nuestros vehículos. ¡Es un momento!
                                </p>
                                <a href="obtener_documentacion.php" class="btn btn-primary">Crear documentación ahora</a>
                            </div>
                        </div>

                    <?php endif; ?>

                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Cosmin - Maserati 2025</div>

                        <div class="redes">
                            <a href="https://x.com/?lang=es" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/twitterx.svg" type="" width="30px" height="30px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.instagram.com/" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/instagram.svg" type="" width="35px" height="35px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.facebook.com/?locale=es_ES" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/facebook.svg" type="" width="35px"
                                    height="35px"></object></a>
                        </div>

                        <div>
                            <i class="fas fa-phone-alt"></i>
                            <span>+34 642 74 02 39</span>
                        </div>

                        <div>
                            <a href="accesibilidad.php">Accesibilidad</a>
                            &middot;
                            <a href="politica_privacidad.php">Política de Privacidad</a>
                            &middot;
                            <a href="politica_cookies.php">Política de Cookies</a>
                            &middot;
                            <a href="terminos.php">Términos &amp; condiciones de uso</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script>
        function enableEdit() {
            document.getElementById('documentData').style.display = 'none';
            document.getElementById('editForm').style.display = 'block';
        }

        function cancelEdit() {
            document.getElementById('documentData').style.display = 'block';
            document.getElementById('editForm').style.display = 'none';
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="../assets/js/scripts.js"></script>
</body>

</html>