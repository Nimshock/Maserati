<script>

    document.addEventListener('DOMContentLoaded', function () {
        

        var editarUsuarioBtn = document.getElementById('editarUsuario');
        if (editarUsuarioBtn) {
            editarUsuarioBtn.addEventListener('click', function () {
                var userInput = document.getElementById('usuario');
                if(userInput) {
                    userInput.readOnly = false;
                    userInput.focus();
                    userInput.select();
                }
            });
        }
        

        var formGuardaCambios = document.getElementById('formGuardaCambios');
        if(formGuardaCambios) {
            formGuardaCambios.addEventListener('submit', function (event) {
                var confirmacion = confirm("¿Estás seguro de guardar los cambios?");
                if (!confirmacion) {
                    event.preventDefault();
                }
            });
        }
    });


    window.addEventListener('load', function() {
        
        function getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return parts.pop().split(';').shift();
        }

        function setCookie(name, value) {
            const now = new Date();
            const yearLater = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
            document.cookie = `${name}=${value}; expires=${yearLater.toUTCString()}; path=/`;
        }

        function showCookieConsent() {
            var cookieConsent = document.getElementById('cookieConsent');
            if (cookieConsent && !getCookie('cookieAnalitica')) {
                cookieConsent.style.display = 'block';
            }
        }
        
        showCookieConsent();

        var btnAccept = document.getElementById('btnAccept');
        if(btnAccept) {
            btnAccept.addEventListener('click', function() {
                setCookie('cookieAnalitica', 'aceptado');
                document.getElementById('cookieConsent').style.display = 'none';
            });
        }

        var btnReject = document.getElementById('btnReject');
        if(btnReject) {
            btnReject.addEventListener('click', function() {
                document.getElementById('cookieConsent').style.display = 'none';
            });
        }
    });
</script>