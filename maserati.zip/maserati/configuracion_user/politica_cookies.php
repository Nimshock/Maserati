<?php

session_start();

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: ../login.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" href="../assets/images/logos-image/logoMaseratiDorado.png" type="">
    <title>Política de Cookies - Maserati</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        .card-body {
        margin-left: 20px;
        margin-right: 20px;
        padding: 20px;
        max-width: 800px;
        text-align: justify;
        }
        .card{
            margin-left:20%;
            margin-right:20%;
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="../index.php">Maserati&nbsp;&nbsp;<img src="../assets/images/logos-image/logoMaserati2.png"width="15%" /></a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <ul class="navbar-nav ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i>&nbsp;Cuenta</a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="configuracion.php">Configuración</a></li>
                    <li><hr class="dropdown-divider" /></li>
                    <li><a class="dropdown-item" href="../logout.php">Cerrar sesión</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Principal</div>
                        <a class="nav-link" href="configuracion.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-home"></i></div>
                            Configuración
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">En sesión como: <br><?php echo $_SESSION['usuario']; ?></div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div id="cookieConsent" class="alert alert-info alert-dismissible fade show" role="alert" style="display: none;">
                    <strong>Este sitio web utiliza cookies analíticas para analizar tus hábitos de navegación y aprender a mejorar para garantizar la mejor experiencia en nuestro sitio web.<br>
                    Toda la información recopilada es no confidencial, además puede comprobar qué información se recopila en nuestra <a href="politica_cookies.php">Política de Cookies</a>.
                    <br>Al hacer clic en Aceptar, aceptas el uso de las cookies analíticas.<br><br></strong>
                    <button type="button" class="btn btn-primary btn-sm" id="btnAccept">Aceptar</button>
                    <button type="button" class="btn btn-primary btn-sm" id="btnReject">Rechazar</button>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Maserati</h1>
                        <ol class="breadcrumb mb-4">
                            <i class="fas fa-cookie-bite"></i>&nbsp;
                            <li class="breadcrumb-item active">Política de Cookies</li>
                        </ol>
                    <div class="row">
                        <div class="col-12">
                            <div class="card mb-4">
                                <div class="card-body text-justify mx-auto">
                                    <strong>¿Qué son las Cookies?</strong>
                                    <p>Entendemos por cookies como tecnologías de almacenamiento y recuperación de información cuando un usuario navega.
                                        En general, estas tecnologías sirven para finalidades muy diversas, como por ejemplo, reconocerte como usuario,
                                        obtener información sobre tus hábitos de navegación o personalizar la forma en que se muestra el contenido.
                                        Los usos concretos que hacemos de estas tecnologías se describen en párrafos posteriores.
                                    </p>
                                    <p>Existen diferentes tipos de cookies en función, sobre todo, de la naturaleza de las mismas,
                                    a continuación explicamos en detalle las cookies utilizadas en nuestro sitio web y cómo categorizarlas:

                                    <ul>
                                        <li><strong>Según el plazo de tiempo:</strong></li><br>
                                        <ul>
                                            <li><strong>Cookies de sesión:</strong> son aquellas diseñadas para recabar y almacenar datos mientras el usuario accede a una página web.
                                            <br>Se suelen emplear para almacenar información que solo interesa conservar para la prestación del servicio solicitado por el usuario 
                                            <br>en una sola ocasión (por ejemplo, una lista de productos adquiridos) y desaparecen al terminar la sesión.</li><br>
                                            <li><strong>Cookies persistentes:</strong> son aquellas en las que los datos siguen almacenados en el terminal y pueden ser accedidos y tratados
                                            <br>durante un periodo definido por el responsable de la cookie, y que puede ir de unos minutos a varios años.</li>
                                        </ul><br>
                                        <li><strong>Según su finalidad:</strong></li><br>
                                        <ul>
                                            <li><strong>Cookies técnicas:</strong> son aquellas que permiten al usuario la navegación a través de una página web, plataforma o aplicación y la utilización
                                            <br>de las diferentes opciones o servicios que en ella existan, incluyendo aquellas que el editor utiliza para permitir la gestión y operativa de la página web
                                            <br>y habilitar sus funciones y servicios (como por ejemplo, identificar la sesión, acceder a partes de acceso restringido y finalidades similares de naturaleza técnica).</li><br>
                                            <li><strong>Cookies de personalización:</strong> son aquellas que permiten recordar información para que el usuario acceda al servicio con determinadas características
                                            <br>que pueden diferenciar su experiencia de la de otros usuarios, como, por ejemplo, el idioma, el número de resultados a mostrar cuando el usuario realiza una búsqueda, etc.</li><br>
                                            <li><strong>Cookies de análisis:</strong> son aquellas que permiten al responsable de las mismas el seguimiento y análisis del comportamiento de los usuarios de los sitios web
                                            <br>a los que están vinculadas, incluida la cuantificación de los impactos de los anuncios. Este tipo de cookies se utiliza en la medición de la actividad de los sitios web,
                                            <br>aplicación o plataforma, con el fin de introducir mejoras en función del análisis de los datos de uso que hacen los usuarios del servicio.</li>
                                        </ul><br>
                                        <li><strong>Según la entidad que las gestiona:</strong></li><br>
                                        <ul>
                                            <li><strong>Cookies propias:</strong> son aquellas que se envían al equipo terminal del usuario desde un equipo o dominio gestionado por el propio editor
                                            <br>y desde el que se presta el servicio solicitado por el usuario.</li>
                                        </ul>
                                    </ul>

                                    <strong>Cómo administrarlas</strong>
                                    <p>En el presente apartado se lleva a cabo una breve exposición de cómo consultar y llevar a cabo la configuración del sistema de cookies en relación a los navegadores
                                    <br>más comunes o más utilizados por los usuarios; en este sentido, prácticamente todos los navegadores permiten al usuario obtener información general sobre las cookies instaladas
                                    <br>en una página web, concretamente verificar la existencia de las mismas, su duración o el sistema de eliminación.
                                    <br><br>En este sentido, a título informativo, se facilitan una serie de enlaces relacionados:<br><br>
                                    
                                    <a href="https://support.google.com/chrome/answer/95647?hl=es" target="_blank">Google Chrome</a><br>
                                    <a href="https://support.mozilla.org/es/kb/cookies-informacion-que-los-sitios-web-guardan-en-" target="_blank">Mozilla Firefox</a><br>
                                    <a href="https://support.apple.com/es-es/guide/safari/sfri11471/mac" target="_blank">Safari</a>
                                
                                    <br><br>A título informativo se indica que habitualmente la configuración de las cookies se suele llevar a cabo pulsando F12, clicando en la pestaña "Application" y en la sección "Cookies"
                                    <br>aunque conviene tener en cuenta que si se impide el uso de todas las cookies, el contenido de la web asi como determinadas funciones podrían verse afectados.</p>



                                    <strong>Período de conservación</strong>
                                    <p>La conservación de los datos recogidos a través de las cookies estará relacionada en función de la finalidad por la cual se recaba, sin perjuicio de lo establecido legalmente.
                                    <br>En nuestro caso, la caducidad de las cookies analíticas coincide con el perdiodo de almacenamiento de su información, un año.
                                    </p>

                                    <strong>Véase también</strong>
                                    <p>Para más información acerca del tratamiento de datos personales y similares, puede consultar nuestra <a href="politica_privacidad.php">Política de Privacidad</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Cosmin - Maserati 2025</div>

                        <div class="redes">
                            <a href="https://x.com/?lang=es" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/twitterx.svg" type="" width="30px" height="30px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.instagram.com/" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/instagram.svg" type="" width="35px" height="35px"></object>
                            </a>
                        </div>

                        <div class="redes">
                            <a href="https://www.facebook.com/?locale=es_ES" target="_blank"
                                style="color: inherit; text-decoration: none;"
                                onclick="if(getCookie('cookieAnalitica') === 'aceptado') cookieAnalitica++;">
                                <object data="../assets/svg/facebook.svg" type="" width="35px" height="35px"></object></a>
                        </div>


                        <div>
                            <i class="fas fa-phone-alt"></i>
                            <span>+34 642 74 02 39</span>
                        </div>

                        <div>
                            <a href="accesibilidad.php">Accesibilidad</a>
                            &middot;
                            <a href="politica_privacidad.php">Política de Privacidad</a>
                            &middot;
                            <a href="politica_cookies.php">Política de Cookies</a>
                            &middot;
                            <a href="terminos.php">Términos &amp; condiciones de uso</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script>
        function getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return parts.pop().split(';').shift();
        }
        function setCookie(name, value) {
            const now = new Date();
            const yearLater = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
            document.cookie = `${name}=${value}; expires=${yearLater.toUTCString()}; path=/`;
        }
        function showCookieConsent() {
            if (!getCookie('cookieAnalitica')) {
                document.getElementById('cookieConsent').style.display = 'block';
            }
        }
        document.getElementById('btnAccept').addEventListener('click', function() {
            setCookie('cookieAnalitica', 'aceptado');
            document.getElementById('cookieConsent').style.display = 'none';
        });
        document.getElementById('btnReject').addEventListener('click', function() {
            document.getElementById('cookieConsent').style.display = 'none';
        });
        window.addEventListener('load', showCookieConsent);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="../assets/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="../assets/js/datatables-simple-demo.js"></script>
</body>
</html>