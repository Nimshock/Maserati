<?php
session_start();

require_once __DIR__ . '/../config/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $id = $_POST['id'];

    if (!empty($id)) {
        $query_verificar = "SELECT COUNT(*) AS count FROM usuarios WHERE usuario = ? AND id != ?";
        $stmt_verificar = $conn->prepare($query_verificar);
        $stmt_verificar->bind_param("si", $usuario, $id);
        $stmt_verificar->execute();
        $result_verificar = $stmt_verificar->get_result();
        $row_verificar = $result_verificar->fetch_assoc();
        $usuario_existente = $row_verificar['count'] > 0;

        if ($usuario_existente) {
            $_SESSION['update_error'] = "El nombre de usuario ya está en uso. Por favor, elige otro.";
            header("location: configuracion.php");
            exit();
        } else {
            $sql = "UPDATE usuarios SET usuario = ?, updated_at = CURRENT_TIMESTAMP() WHERE id = ?";

            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("si", $usuario, $id);

                if ($stmt->execute()) {
                    $_SESSION['usuario'] = $usuario;
                    $_SESSION['update_success'] = true;

                    header("location: configuracion.php");
                    exit();
                } else {
                    echo "Se produjo un error inesperado. Inténtelo más tarde o llame al número de contacto.";
                }

                $stmt->close();
            }
        }
    } else {
        echo "Error: ID de usuario no encontrado.";
    }

    $conn->close();
}
?>