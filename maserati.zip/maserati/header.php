<?php


$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}


?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-menu-color="light" data-topbar-color="dark">

<body>

    <!-- HEADER -->
    <div class="navbar">
        <div class="navbar-inner">
            <div class="container">

                <!-- LOGOTIPO -->
                <a href="#" class="brand">
                    <img src="assets/images/logos-image/logoMaserati.png" width="120" height="40" alt="Logo" />
                </a>

                <!-- BOTÓN NAVEGACIÓN PANTALLA MÁS PEQUEÑA -->
                <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <i class="icon-menu"></i>
                </button>

                <!-- EL MENU DE LA PÁGINA WEB -->
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav" id="top-navigation">
                        <li class="active"><a href="#inicio">Inicio</a></li>
                        <li><a href="#caracteristicasCoches">Características</a></li>
                        <li><a href="#modelosCoches">Modelos</a></li>
                        <li><a href="#sobreNosotros">Sobre nosotros</a></li>
                        <li><a href="#clientes">Clientes</a></li>
                        <li><a href="#precios">Precios</a></li>
                        <li><a href="#contactos">Contactos</a></li>

                        <?php if ($isLoggedIn): ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                Cuenta <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="configuracion_user/configuracion.php">Configuración</a></li> 
                                <li><a href="logout.php">Cerrar sesión</a></li>
                            </ul>
                        </li>

                        <?php else: ?>
                        <li><a href="login.php">Iniciar Sesión</a></li>
                        <li><a href="register.php">Registrarse</a></li>
                        <?php endif; ?>

                    </ul>
                </div>
                <!-- FIN DEL MENU DE LA PÁGINA WEB -->
            </div>
        </div>
    </div>
    <!-- FIN HEADER -->
</body>

</html>