<?php

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}
?>



<!-- CONTENEDOR SECCIÓN CARACTERÍSTICAS -->
<div class="section primary-section" id="caracteristicasCoches">
    <div class="container">

        <!-- CONTENEDOR TÍTULO CARACTERÍSTICAS -->
        <div class="title">
            <h1>Nuestras características</h1>
            <p>Combinando lujo, innovación y prestaciones para crear vehículos exclusivos.</p>
        </div>
        <!-- CONTENEDOR TÍTULO CARACTERÍSTICAS -->

        <!-- CONTENEDOR DE CARACTERíSTICAS -->
        <div class="row-fluid">

            <!-- CARACTERíSTICAS 1 -->
            <div class="span4">
                <div class="centered service">

                    <img class="img-circle" src="assets/images/caracteristicas/maseratiLujo.png" alt="service 1"
                        style="height: 199px; width: 235px; margin-left: 0px;">

                    <h3 style="margin-bottom:7px; margin-top:-20px">Lujo</h3>
                    <p>
                        Maserati es el símbolo perfecto del lujo y la elegancia sobre ruedas.
                    </p>
                </div>
            </div>

            <!-- CARACTERíSTICAS 2 -->
            <div class="span4">
                <div class="centered service">

                    <img class="img-circle" src="assets/images/caracteristicas/maseratiInnovacion.png" alt="service 2"
                        style="height: 170px; margin-left: 0px;" />

                    <h3>Inovación</h3>
                    <p>
                        Maserati fusiona lujo e innovación, ofreciendo coches que
                        que redefinen la experiencia de conducción.
                    </p>
                </div>
            </div>

            <!-- CARACTERíSTICAS 3 -->
            <div class="span4">
                <div class="centered service">

                    <img class="img-circle" src="assets/images/caracteristicas/maseratiRendimiento.png" alt="service 3"
                        style="height: 183px; width: 253px; ">

                    <h3 style="margin-top:-10px">Rendimiento</h3>
                    <p>
                        Combina prestaciones excepcionales con el lujo,
                        creando coches diseñados para aquellos que 
                        buscan potencia y elegancia en cada detalle.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- FIN CONTENEDOR SECCIÓN CARACTERÍSTICAS -->