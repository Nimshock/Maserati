<?php
// config.php

$config = parse_ini_file('config.ini', true);

$DB_HOST = $config['database']['DB_HOST'];
$DB_USER = $config['database']['DB_USER'];
$DB_PASS = $config['database']['DB_PASS'];
$DB_NAME = $config['database']['DB_NAME'];

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
