<?php

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}
?>

<!-- CONTENEDOR DE CLIENTES -->
<div id="clientes">
        <div class="section primary-section">
            <div class="triangle"></div>
            <div class="container">
                <div class="title">
                    <h1>Opiniones de los clientes</h1>
                    <p>
                        Los propietarios destacan la potencia, la respuesta del motor
                        y la sensación de exclusividad al conducir un coche de lujo.
                    </p>
                </div>

                <!-- CONTENEDOR DE LAS 3 RESEÑAS -->
                <div class="row">
                    <div class="span4">
                        <div class="testimonial">
                            <p>
                                Compré un Maserati GranCabrio hace seis meses y desde el primer día 
                                me ha impresionado en todos los sentidos. Es un coche que fusiona a
                                la perfección el lujo con las prestaciones. La conducción es suave,
                                pero también es ágil cuando lo necesito. ágil cuando lo necesito.
                                que sea. Los materiales del interior son de primera clase, y la y 
                                la tecnología es avanzada.
                            </p>
                            <div class="whopic">
                                <div class="arrow"></div>
                                <img src="assets/images/clientes/Client1.png" class="centered" alt="client 1">
                                <strong>Robert Smith
                                    <small>Cliente</small>
                                </strong>
                            </div>
                        </div>
                    </div>

                    <!-- CONTENEDOR RESEÑA 2 -->
                    <div class="span4">
                        <div class="testimonial">
                            <p>
                                Llevo conduciendo mi Maserati Levante desde hace un año y medio,
                                y no podría estar más satisfecho con la experiencia. La potencia
                                y la sensación de conducir un SUV de lujo es única. El diseño y 
                                la calidad interior son excepcionales.
                            </p>
                            <div class="whopic">
                                <div class="arrow"></div>
                                <img src="assets/images/clientes/Client2.png" class="centered" alt="client 2">
                                <strong>Steve Anderson
                                    <small>Cliente</small>
                                </strong>
                            </div>
                        </div>
                    </div>
                    <!-- FIN CONTENEDOR RESEÑA 2 -->

                    <!-- CONTENEDOR RESEÑA 3 -->
                    <div class="span4">
                        <div class="testimonial">
                            <p>
                                Mi Ghibli es, sin duda, el coche más impresionante que he tenido nunca.
                                Me encanta su diseño deportivo y su interior de alta gama. Es rápido, 
                                ágil y siempre me siento especial al conducirlo.
                            </p>
                            <div class="whopic">
                                <div class="arrow"></div>
                                <img src="assets/images/clientes/Client3.png" class="centered" alt="client 3">
                                <strong>Lucia Pérez
                                    <small>Cliente</small>
                                </strong>
                            </div>
                        </div>
                    </div>
                    <!-- FIN CONTENEDOR RESEÑA 3 -->
                </div>

                <p class="testimonial-text">
                    La perfección no se alcanza cuando no hay nada más que añadir,
                    sino cuando no queda nada que quitar.
                </p>
            </div>
        </div>
    </div>
    <!-- CONTENEDOR DE CLIENTES -->

    <div class="section third-section">
        <div class="container centered">
            <div class="sub-section">
                <div class="title clearfix">
                    <div class="pull-left">
                        <h3>Maserati interior</h3>
                    </div>
                    <ul class="client-nav pull-right">
                        <li id="client-prev"></li>
                        <li id="client-next"></li>
                    </ul>
                </div>
                <ul class="row client-slider" id="clint-slider">
                    <li>
                        <a>
                            <img src="assets/images/interiorMaserati/volanteMaserati.jpg" alt="Volante Maserati">
                        </a>
                    </li>
                    <li>
                        <a>
                            <img src="assets/images/interiorMaserati/asientosDelanteros.jpg" alt="Asientos Delanteros">
                        </a>
                    </li>
                    <li>
                        <a>
                            <img src="assets/images/interiorMaserati/consolaCentral.jpg" alt="Consola Central">
                        </a>
                    </li>
                    <li>
                        <a>
                            <img src="assets/images/interiorMaserati/asientosTraseros.jpg" alt="Asientos Traseros">
                        </a>
                    </li>
                    <li>
                        <a>
                            <img src="assets/images/interiorMaserati/techoInteriorMaserati.jpg" alt="Techo Interior">
                        </a>
                    </li>
                    <li>
                        <a>
                            <img src="assets/images/interiorMaserati/puertaInteriorMaserati.jpg" alt="Puerta Interior">
                        </a>
                    </li>
                    <li>
                        <a>
                            <img src="assets/images/interiorMaserati/vistaGeneralDesdeAtrasMaserati.jpg" alt="Habitaculo Vista Trasera">
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
