<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once 'config/config.php';

    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    $query = "SELECT id, contrasena, role FROM usuarios WHERE usuario = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $hashed_password, $role);
        $stmt->fetch();

        if ($role == "admin" && password_verify($contrasena, $hashed_password)) {
            $_SESSION['loggedin'] = true;
            $_SESSION['usuario'] = $usuario;
            $_SESSION['role'] = $role; // <-- AÑADE ESTA LÍNEA
            header("location: configuracion_admin/admin_panel.php");
            exit;
        } else {
            if ($role == "admin") {
                $error_message = "Usuario o contraseña incorrectos";
            } else {
                $error_message = "Esta cuenta no tiene permisos de administrador";
            }
        }
    } else {
        $error_message = "Usuario o contraseña incorrectos";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Acceso de Administrador - Maserati" />
    <meta name="author" content="Maserati Web" />
    <link rel="icon" href="assets/images/ico/logoMaseratiDorado.ico" type="image/x-icon">
    <title>Inicio de admin - Maserati</title>
    <link href="assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        :root {
            --admin-accent-color: #4A5568; 
            --admin-accent-color-rgb: 74, 85, 104;
            --admin-card-bg: #2D3748; 
            --admin-input-bg: #1A202C;
            --admin-text-primary: #E2E8F0; 
            --admin-text-secondary: #A0AEC0; 
            --admin-border-color: rgba(255, 255, 255, 0.1);
            --admin-body-overlay: rgba(10, 10, 15, 0.65); 
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: url('assets/images/login-images/background_admin_2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: var(--admin-text-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
            position: relative;
        }

        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--admin-body-overlay);
            z-index: -1;
        }

        #layoutAuthentication {
            width: 100%;
            position: relative;
            z-index: 1;
        }
        
        .card {
            background-color: var(--admin-card-bg);
            border: 1px solid var(--admin-border-color);
            border-radius: 0.5rem; 
            box-shadow: 0 0.25rem 1.5rem rgba(0,0,0,0.35); 
        }

        .card-header {
            background-color: transparent;
            border-bottom: 1px solid var(--admin-border-color);
            padding-top: 2rem;
            padding-bottom: 1rem;
            text-align: center;
        }

        .logotipoMaserati {
            width: 90px;
            height: auto;
            margin-bottom: 1rem;
        }

        .card-header h3 {
            color: var(--admin-text-primary);
            margin-right: 50px;
            font-weight: 400;
            font-size: 1.6rem;
            margin-top: 0;
            margin-bottom: 0;
        }
        
        .user-icon {
            position: absolute;
            top: 15px;
            right: 15px;
            background-color: rgba(255,255,255,0.05);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: var(--admin-text-secondary);
            text-decoration: none;
            transition: background-color 0.2s ease, color 0.2s ease;
        }

        .user-icon:hover {
            background-color: rgba(255,255,255,0.1);
            color: var(--admin-text-primary);
        }

        .card-body {
            padding: 2rem;
        }

        .form-floating label {
            color: var(--admin-text-secondary);
        }

        .form-control {
            background-color: var(--admin-input-bg);
            border: 1px solid var(--admin-border-color);
            color: var(--admin-text-primary);
            border-radius: 0.375rem;
        }
        .form-control:focus {
            background-color: var(--admin-input-bg);
            border-color: var(--admin-accent-color);
            box-shadow: 0 0 0 0.25rem rgba(var(--admin-accent-color-rgb), 0.35);
            color: var(--admin-text-primary);
        }
        
        .form-control::placeholder { color: var(--admin-text-secondary); opacity: 1; }
        .form-control:-ms-input-placeholder { color: var(--admin-text-secondary); }
        .form-control::-ms-input-placeholder { color: var(--admin-text-secondary); }

        .btn-primary {
            background-color: var(--admin-accent-color);
            border-color: var(--admin-accent-color);
            padding: 0.65rem 1.25rem;
            font-weight: 500;
            width: 100%;
            border-radius: 0.375rem;
            color: var(--admin-text-primary);
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-primary:hover, .btn-primary:focus {
            background-color: #3B4554;
            border-color: #3B4554;
            box-shadow: 0 0 0 0.25rem rgba(var(--admin-accent-color-rgb), 0.3);
        }
        
        .alert {
            border-radius: 0.375rem;
            font-size: 0.9em;
            padding: 0.8rem 1rem;
        }
        .alert-danger {
            background-color: rgba(192, 57, 43, 0.15);
            border: 1px solid rgba(192, 57, 43, 0.3);
            color: #f5c6cb;
        }
    </style>
</head>
<body>
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5"> 
                                <div class="card-header">
                                    <img src="assets/images/logos-image/logoMaserati.png" alt="Logotipo Maserati" class="logotipoMaserati">
                                    <h3 class="text-center font-weight-light my-4">Cuenta de administración</h3>
                                    <a href="login.php" class="user-icon" title="Acceso Usuario">
                                        <i class="fas fa-user"></i>
                                    </a>
                                </div>
                                <div class="card-body">
                                    <form method="POST" action="login_admin.php">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="usuario" name="usuario" type="text" placeholder="Usuario" required />
                                            <label for="usuario">Usuario</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="contrasena" name="contrasena" type="password" placeholder="Contraseña" required />
                                            <label for="contrasena">Contraseña</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                            <button class="btn btn-primary" type="submit">Iniciar sesión</button>
                                        </div>
                                        <?php if (isset($error_message)) : ?>
                                            <div class="alert alert-danger mt-3" role="alert">
                                                <?php echo $error_message; ?>
                                            </div>
                                        <?php endif; ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>