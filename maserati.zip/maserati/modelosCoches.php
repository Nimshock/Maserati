<?php


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}


require_once __DIR__ . '/config/config.php';


$query_modelos = "SELECT id, nombre, tipo, descripcion, imagen_url, fecha_lanzamiento, caracteristicas_cortas, url_oficial FROM modelos";
$result_modelos = $conn->query($query_modelos);
?>
<div class="section secondary-section " id="modelosCoches">
    <div class="triangle"></div>
    <div class="container">
        <div class=" title">
            <h1>Nuestros modelos</h1>
            <p>Modelos Maserati como el elegante GranCabrio y el imponente SUV Levante combinan lujo, diseño italiano y
                prestaciones excepcionales.</p>
        </div>

        <ul class="nav nav-pills">
            <li class="filter" data-filter="all">
                <a href="#noAction">Todo</a>
            </li>
            <li class="filter" data-filter="bev">
                <a href="#noAction">BEV</a>
            </li>
            <li class="filter" data-filter="hibrido">
                <a href="#noAction">Híbrido</a>
            </li>
        </ul>

        <div id="single-project">
            <?php
            mysqli_data_seek($result_modelos, 0);
            while ($coche = $result_modelos->fetch_assoc()):
                ?>
                <div id="slidingDiv-<?php echo $coche['id']; ?>" class="toggleDiv row-fluid single-project">
                    <div class="span6">
                        <img src="<?php echo htmlspecialchars($coche['imagen_url']); ?>"
                            alt="<?php echo htmlspecialchars($coche['nombre']); ?>" />
                    </div>
                    <div class="span6">
                        <div class="project-description">
                            <div class="project-title clearfix">
                                <h3>Maserati - <?php echo htmlspecialchars($coche['nombre']); ?></h3>
                                <span class="show_hide close"><i class="icon-cancel"></i></span>
                            </div>
                            <div class="project-info">
                                <div>
                                    <span><i
                                            class="icon-calendar"></i></span><?php echo date('F Y', strtotime($coche['fecha_lanzamiento'])); ?>
                                </div>
                                <div>
                                    <span style="display: inline-flex; align-items: center;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                            class="bi bi-info-circle" viewBox="0 0 16 16">
                                            <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16" />
                                            <path
                                                d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0" />
                                        </svg>
                                    </span>
                                    <?php echo htmlspecialchars($coche['caracteristicas_cortas']); ?>
                                </div>
                                <div>
                                    <span><i class="icon-link-ext"></i></span><a
                                        href="<?php echo htmlspecialchars($coche['url_oficial']); ?>"
                                        target="_blank"><?php echo htmlspecialchars($coche['url_oficial']); ?></a>
                                </div>
                            </div>
                            <p><?php echo htmlspecialchars($coche['descripcion']); ?></p>
                            <?php if ($documentado == 1): ?>
                                <form action="crear_reserva.php" method="POST" style="margin-top: 10px;">
                                    <input type="hidden" name="modelo_id" value="<?php echo $coche['id']; ?>">
                                    <button type="submit" class="button-sp2">Reservar ahora</button>
                                </form>
                            <?php else: ?>
                                <a href="configuracion_user/obtener_documentacion.php" class="button-sp2"
                                    style="background-color: #5a5a5a; border-color: #5a5a5a; cursor: pointer; color: #fff;">
                                    Crear documentación
                                </a>
                                <p style="font-size: 11px; color: #ccc; margin-top: 5px; padding: 0;">(Necesario para reservar)
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <ul id="portfolio-grid" class="thumbnails row">
            <?php
            mysqli_data_seek($result_modelos, 0);
            while ($coche = $result_modelos->fetch_assoc()):
                ?>
                <li class="span4 mix <?php echo str_replace('í', 'i', strtolower($coche['tipo'])); ?>">
                    <div class="thumbnail">
                        <a href="#single-project" class="more show_hide" rel="#slidingDiv-<?php echo $coche['id']; ?>">
                            <i class="icon-plus"></i>
                        </a>
                        <div class="image-container">
                            <img src="<?php echo htmlspecialchars($coche['imagen_url']); ?>"
                                alt="<?php echo htmlspecialchars($coche['nombre']); ?>">
                        </div>
                        <div class="caption">
                            <h3><?php echo htmlspecialchars($coche['nombre']); ?></h3>
                        </div>
                        <div class="mask"></div>
                    </div>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
</div>