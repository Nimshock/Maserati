<?php


$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}
?>

<!-- CONTENEDOR SOBRE NOSOTROS -->
<div class="section primary-section" id="sobreNosotros">
    <div class="triangle"></div>
    <div class="container">

        <div class="title">
            <h1>¿Quiénes somos?</h1>
            <p>
                Marca italiana de lujo con más de un siglo de historia,
                dedicada a la excelencia en diseño, rendimiento e
                innovación, creando vehículos exclusivos que combinan
                elegancia deportividad y artesanía italiana.
            </p>
        </div>


        <!-- CONTENEDOR PRESIDENTE MASERATI -->
        <div class="row-fluid team">
            <div class="span4" id="first-person">
                <div class="thumbnail">
                    <img src="assets/images/sobreNosotros/Maurizio-Zuares.jpg" alt="team 1">
                    <h3 style="color: white;">Mauricio Zuares</h3>

                    <!-- LISTA DE RRSS -->
                    <ul class="social">

                        <!-- ICONO RS FACEBOOK -->
                        <li>
                            <a href="https://www.facebook.com/Maserati/">
                                <span>
                                    <object data="assets/svg/facebook.svg" type=""></object>
                                </span>
                            </a>
                        </li>

                        <!-- ICONO RS INSTAGRAM -->
                        <li>
                            <a href="https://www.instagram.com/maserati/">
                                <span>
                                    <object data="assets/svg/instagram.svg" type=""></object>
                                </span>
                            </a>
                        </li>

                        <!-- ICONO RS LINKEDIN -->
                        <li>
                            <a href="https://www.linkedin.com/in/maurizio-zuares-a627635/">
                                <span>
                                    <object data="assets/svg/linkedin.svg" type=""></object>
                                </span>
                            </a>
                        </li>
                    </ul>
                    <!-- FIN LISTA DE RRSS -->
                </div>
            </div>
        </div>

        <!-- CONTENEDOR SOBRE NOSOTROS -->
        <div class="about-text centered">
            <h3>Sobre nosotros</h3>
            <p style="text-align: justify;">
                En Maserati somos más que una marca de automóviles de lujo;
                somos una leyenda de la ingeniería italiana, con más más de
                un siglo de historia en la creación de excepcionales.
                Nuestra pasión por la innovación y el diseño nos ha llevado
                a superar los límites de las prestaciones, la elegancia y
                la tecnología. Cada uno de nuestros modelos refleja
                exquisita artesanía, tecnología de vanguardia y una
                incansable dedicación a la perfección. Desde nuestros
                Maserati ha sido sinónimo de exclusividad exclusividad,
                impulsada por una audaz visión para crear vehículos, sino
                símbolos de prestigio y una forma de vida. Hoy, continuamos
                esa tradición, fusionando tradición y modernidad para
                ofrecer experiencias incomparables a nuestros clientes de
                todo el mundo.
            </p>
        </div>
        <!-- FIN CONTENEDOR SOBRE NOSOTROS -->


        <!-- CONTENEDOR CARACTERÍSTICAS -->
        <h3>Características</h3>
        <div class="row-fluid">
            <div class="span6">
                <ul class="skills">
                    <li>
                        <span class="bar" data-width="95%"></span>
                        <h3>Elegancia</h3>
                    </li>
                    <li>
                        <span class="bar" data-width="90%"></span>
                        <h3>Poder</h3>
                    </li>
                    <li>
                        <span class="bar" data-width="80%"></span>
                        <h3>Versatilidad</h3>
                    </li>
                    <li>
                        <span class="bar" data-width="95%"></span>
                        <h3>Lujo</h3>
                    </li>
                </ul>
            </div>
            <!-- FIN CONTENEDOR CARACTERÍSTICAS -->

            <!--  -->
            <div class="span6">
                <div class="highlighted-box center">
                    <h1>Buscando gente</h1>
                    <p>
                        Maserati busca socios que compartan su visión de excelencia
                        innovación y exclusividad. La marca se centra en
                        estratégicas que refuercen su presencia global, tanto comercialmente
                        como en áreas tecnológicas y de diseño.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CONTENDOR SECCIÓN COMPRA MASERATI OFICIAL -->
<div class="section sixth-section">
    <div class="triangle"></div>
    <div class="container centered">
        <p class="large-text">La elegancia no es la abundancia de simplicidad. Es la ausencia de complejidad.</p>
    </div>
</div>
<!-- FIN CONTENDOR SECCIÓN COMPRA MASERATI OFICIAL -->