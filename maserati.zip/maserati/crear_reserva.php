<?php
session_start();


if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}


if (!isset($_POST['modelo_id'])) {
    header("location: index.php#modelosCoches");
    exit;
}

require_once __DIR__ . '/config/config.php';

$usuario_id = $_SESSION['id'];
$modelo_id = $_POST['modelo_id'];


$sql = "INSERT INTO reservas (usuario_id, modelo_id) VALUES (?, ?)";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("ii", $usuario_id, $modelo_id);

    if ($stmt->execute()) {
        header("location: configuracion_user/mis_reservas.php?reserva=success");
    } else {
        header("location: index.php?error=reserva_fallida");
    }
    $stmt->close();
}
$conn->close();
?>