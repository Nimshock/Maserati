<?php

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}
?>

<!-- CONTENEDOR DEL INICIO -->
<div id="inicio">

    <!-- CONTENEDOR SLIDER -->
    <div id="da-slider" class="da-slider">

        <!-- CONTENEDOR TRIÁNGULO -->
        <div class="triangle"></div>

        <!-- IMAGEN COMO FONDO DEL CONTENEDOR SLIDER -->
        <div class="mask"></div>

        <!-- CONTENEDOR PARA CENTRAR LOS 3 SLDIERS -->
        <div class="container">

            <!-- PRIMER SLIDER -->
            <div class="da-slide">
                <h2 class="fittext2">Bienvenido al mundo del motor</h2>
                <p>
                    Una experiencia de conducción sin igual imagina el rugido
                    de un motor que combina la precisión italiana con
                    mundial. Maserati no es sólo un coche.
                </p>
                <a href="https://www.maserati.com/es/es" class="da-link button">Leer más</a>
                <div class="da-img">
                    <img src="assets/images/inicio-menu/maseratiDescapotable.png" alt="image01" width="320">
                </div>
            </div>
            <!-- FIN PRIMER SLIDER -->

            <!-- SEGUNDO SLIDER -->
            <div class="da-slide">
                <h2>Nuestra historia</h2>
                <p>
                    Alfieri, Ettore y Ernesto, que compartían la pasión por la ingeniería y la velocidad.
                    Al principio fabricaban bujías y motores para automóviles, pero su ambición les llevó
                    a construir sus propios coches de carreras.
                </p>
                <a href="https://www.maserati.com/es/es/mundo-maserati/historia" class="da-link button">Leer más</a>
                <div class="da-img">
                    <img src="assets/images/inicio-menu/hermanos-maserati.png" width="320" alt="image02">
                </div>
            </div>
            <!-- FIN SEGUNDO SLIDER -->


            <!-- TERCER SLIDER -->
            <div class="da-slide">
                <h2>Aniversario 110 GranTurismo</h2>
                <p>
                    Más de 110 años de innovación, directamente desde el Motor Valley.
                    Un legado de rendimiento sin precedentes y artesanía italiana que
                    ha culminado en una serie limitada de 110 GranTurismo Folgore.
                </p>
                <a href="https://www.maserati.com/global/en?redirect=1" class="da-link button">Leer más</a>
                <div class="da-img">
                    <img src="assets/images/inicio-menu/gt-110-anniversary_.png" width="320" alt="image03">
                </div>
            </div>
            <!-- FIN TERCER SLIDER -->


            <!-- CONTENEDOR DE LAS FLECHAS DEL SLIDER -->
            <div class="da-arrows">
                <span class="da-arrows-prev"></span>
                <span class="da-arrows-next"></span>
            </div>
            <!-- FIN CONTENEDOR DE LAS FLECHAS DEL SLIDER -->
        </div>
    </div>
    <!-- FIN CONTENEDOR SLIDER -->

</div>
<!-- FIN CONTENEDOR SECCIÓN INICIO -->