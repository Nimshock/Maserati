<?php

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {

    header("location: login.php");
    exit;
}

?>

<div id="precios" class="section fith-section">
    <div class="container">
        <div class="title">
            <h1 style="color: black;">Precios</h1>
            <p style="color: black;">
                Maserati ofrece diferentes planes de mantenimiento dependiendo del modelo.
            </p>
        </div>

        <div class="price-table row-fluid centered-columns">

            <div class="span4 price-column"> 
                <h3>Básico</h3>
                <ul class="list">
                    <li class="price">199,99€</li>
                    <li><strong>Gratis</strong> Limpieza</li>
                    <li><strong>24/7</strong> Soporte</li>
                    <li><strong>5 litros</strong> Gasolina</li>
                </ul>
            </div>

            <div class="span4 price-column">
                <h3>Superior</h3>
                <ul class="list">
                    <li class="price">399,99€</li>
                    <li><strong>Gratis</strong> Limpieza superior</li>
                    <li><strong>24/7</strong> Soporte superior</li>
                    <li><strong>25 litros</strong> Gasolina</li>
                </ul>
            </div>


            <div class="span4 price-column">
                <h3>VIP</h3>
                <ul class="list">
                    <li class="price">799,99€</li>
                    <li><strong>Gratis</strong> Limpieza VIP</li>
                    <li><strong>24/7</strong> Suporte VIP</li>
                    <li><strong>50 litros</strong> Gasolina</li>
                </ul>
            </div>

        </div>
        <div class="centered">
            <p class="price-text">
                Contacte para más información.
            </p>
        </div>
    </div>
</div>