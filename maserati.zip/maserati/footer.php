<?php

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}
?>

<!-- CONTENEDOR CONTACTO -->
<div class="container">
    <div class="span9 center contact-info">
        <p>Av. de Logroño, 32, 50011 Zaragoza</p>
        <p class="info-mail"> info@maserati.com</p>
        <p>+34 976 32 40 50</p>
        <div class="title">
            <h3>Nuestras redes sociales</h3>
        </div>
    </div>
    <hr>
    <!-- FIN CONTENEDOR CONTACTO -->


    <!-- CONTENEDOR DE REDES SOCIALES -->
    <div class="row-fluid centered">
        <ul class="social">

            <!-- FIN ICONO FACEBOOK -->
            <li>
                <a href="https://www.facebook.com/Maserati/">
                    <span>
                        <object data="assets/svg/facebook.svg" type=""></object>
                    </span>
                </a>
            </li>
            <!-- FIN ICONO FACEBOOK -->

            <!-- ICONO X -->
            <li>
                <a href="https://x.com/Maserati_HQ">
                    <object data="assets/svg/twitterx.svg" type=""></object>
                </a>
            </li>
            <!-- FIN ICONO X -->

            <!-- ICONO YOUTUBE -->
            <li>
                <a href="https://www.youtube.com/maserati">
                    <object data="assets/svg/youtube.svg" type=""></object>
                </a>
            </li>
            <!-- FIN ICONO YOUTUBE -->

            <!-- ICONO INSTAGRAM -->
            <li>
                <a href="https://www.instagram.com/maserati/">
                    <object data="assets/svg/instagram.svg" type=""></object>
                </a>
            </li>
            <!-- FIN ICONO INSTAGRAM -->

            <!-- ICONO LINKEDIN -->
            <li>
                <a href="https://www.linkedin.com/company/maserati/">
                    <object data="assets/svg/linkedin.svg" type=""></object>
                </a>
            </li>
            <!-- FIN ICONO LINKEDIN -->

            <!-- ICONO TIK TOK -->
            <li>
                <a href="https://www.tiktok.com/@maserati">
                    <object data="assets/svg/tiktok.svg" type=""></object>
                </a>
            </li>
            <!-- FIN ICONO TIK TOK -->

        </ul>
    </div>
</div>
</div>
</div>
<!-- FIN CONTENEDOR DE REDES SOCIALES -->


<!-- CONTENEDOR DEL PIE DE PÁGINA -->
<div class="footer">
    <p>
        &copy; 2025 Diseñado por <a href="https://github.com/Nimshock">Cosmin</a>, <a
        href="configuracion_user/politica_privacidad.php">Aviso legal y Política de privacidad</a>
    </p>
</div>
<!-- FIN CONTENEDOR DEL PIE DE PÁGINA -->


<!-- CONTENEDOR DEL BOTÓN DESPLAZAMIENTO AL INICIO -->
<div class="scrollup">
    <a href="inicio.php">
        <i class="icon-up-open"></i>
    </a>
</div>
<!-- FIN CONTENEDOR DEL BOTÓN DESPLAZAMIENTO AL INICIO -->
</body>

</html>