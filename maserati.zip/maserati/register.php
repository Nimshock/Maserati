<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once __DIR__ . '/config/config.php';
    
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];
    $contrasena_confirm = $_POST['contrasena_confirm'];

    $query_verificar = "SELECT COUNT(*) AS count FROM usuarios WHERE usuario = ?";
    $stmt_verificar = $conn->prepare($query_verificar);
    $stmt_verificar->bind_param("s", $usuario);
    $stmt_verificar->execute();
    $result_verificar = $stmt_verificar->get_result();
    $row_verificar = $result_verificar->fetch_assoc();
    $usuario_existente = $row_verificar['count'] > 0;

    if ($usuario_existente) {
        $error_message = "Ya existe un usuario con ese nombre. Por favor, elige otro.";
    } elseif ($contrasena !== $contrasena_confirm) {
        $error_message = "Las contraseñas no coinciden. Por favor, inténtalo de nuevo.";
    } else {
        $hashed_password = password_hash($contrasena, PASSWORD_DEFAULT);

        $role = "Usuario";

        $query_insertar = "INSERT INTO usuarios (usuario, contrasena, role) VALUES (?, ?, ?)";
        $stmt_insertar = $conn->prepare($query_insertar);
        $stmt_insertar->bind_param("sss", $usuario, $hashed_password, $role);
        $stmt_insertar->execute();

        header("Location: login.php?registered=true");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Registro de cuenta - Maserati" />
    <meta name="author" content="Maserati Web" />
    <link rel="icon" href="assets/images/maserati-icon.png" type="image/png">
    <title>Registro - Maserati</title>
    <link href="assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        :root {
            --maserati-blue: #0A246A;
            --maserati-card-bg: #1A1D24; 
            --maserati-input-bg: #2C2F36;
            --maserati-text-primary: #FFFFFF;
            --maserati-text-secondary: #adb5bd;
            --maserati-border-color-rgba: rgba(255, 255, 255, 0.15);
            --maserati-yellow-focus: #FFD700; 
            --maserati-yellow-focus-rgb: 255, 215, 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: url('assets/images/login-images/backgroundRegister_2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: var(--maserati-text-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }

        #layoutAuthentication {
            width: 100%;
            position: relative;
        }
        
        .card {
            background-color: var(--maserati-card-bg);
            border: 1px solid var(--maserati-border-color-rgba);
            border-radius: 0.5rem; 
            box-shadow: 0 0.25rem 1rem rgba(0,0,0,0.3); 
        }

        .card-header {
            background-color: transparent;
            border-bottom: 1px solid var(--maserati-border-color-rgba);
            padding-top: 2rem;
            padding-bottom: 1rem;
            text-align: center;
        }

        .logotipoMaserati {
            width: 90px;
            height: auto;
            margin-bottom: 1rem;
        }

        .card-header h3 {
            color: var(--maserati-text-primary);
            font-weight: 300;
            font-size: 1.75rem;
            margin-top: 0;
            margin-bottom: 0;
        }
        
        .card-body {
            padding: 2rem;
        }

        .form-floating {
            position: relative;
        }

        .form-floating label {
            color: var(--maserati-text-secondary);
        }

        .form-control {
            background-color: var(--maserati-input-bg);
            border: 1px solid var(--maserati-border-color-rgba);
            color: var(--maserati-text-primary);
            border-radius: 0.375rem;
        }
        .form-control:focus {
            background-color: var(--maserati-input-bg);
            border-color: var(--maserati-yellow-focus);
            box-shadow: 0 0 0 0.25rem rgba(var(--maserati-yellow-focus-rgb), 0.25);
            color: var(--maserati-text-primary);
        }
        
        .form-control::placeholder { color: var(--maserati-text-secondary); opacity: 1; }
        .form-control:-ms-input-placeholder { color: var(--maserati-text-secondary); }
        .form-control::-ms-input-placeholder { color: var(--maserati-text-secondary); }

        .info-icon {
            position: absolute;
            top: 50%; 
            right: 1rem; 
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--maserati-text-secondary);
        }
        .info-icon:hover {
            color: var(--maserati-text-primary);
        }

        .btn-primary {
            background-color: var(--maserati-blue);
            border-color: var(--maserati-blue);
            padding: 0.65rem 1.25rem;
            font-weight: 500;
            width: 100%;
            border-radius: 0.375rem;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-primary:hover, .btn-primary:focus {
            background-color: #08205A; 
            border-color: #08205A;
            box-shadow: 0 0 0 0.25rem rgba(var(--maserati-blue), 0.25);
        }
        
        .card-footer {
            background-color: transparent;
            border-top: 1px solid var(--maserati-border-color-rgba);
            padding-top: 1.5rem;
            padding-bottom: 1.5rem;
        }

        .card-footer .small a {
            color: var(--maserati-text-secondary);
            text-decoration: none;
        }

        .card-footer .small a:hover {
            color: var(--maserati-text-primary);
            text-decoration: underline;
        }
        
        .alert {
            border-radius: 0.375rem;
            font-size: 0.9em;
            padding: 0.8rem 1rem;
        }
        .alert-success {
            background-color: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #e2f0e6; 
        }
        .alert-danger {
            background-color: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #f8d7da;
        }
    </style>
</head>
<body>
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="card my-5">
                                <div class="card-header">
                                    <img src="assets/images/logos-image/logoMaserati.png" alt="Logotipo Maserati" class="logotipoMaserati">
                                    <h3>Crea tu cuenta</h3>
                                </div>
                                <div class="card-body">
                                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputUsuario" name="usuario" type="text" placeholder="Usuario" required />
                                            <label for="inputUsuario">Usuario</label>
                                            <span class="info-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Este nombre hará referencia a cómo te identifiques en la web; puede ser tu nombre, o cualquier palabra original que escojas">
                                                <i class="fas fa-info-circle fa-lg"></i>
                                            </span>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputContrasena" name="contrasena" type="password" placeholder="Contraseña" required />
                                            <label for="inputContrasena">Contraseña</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputContrasenaConfirm" name="contrasena_confirm" type="password" placeholder="Confirmar contraseña" required />
                                            <label for="inputContrasenaConfirm">Confirmar contraseña</label>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <button class="btn btn-primary" type="submit">Registrarse</button>
                                        </div>
                                    </form>
                                    <?php if (isset($error_message)) : ?>
                                        <div class="alert alert-danger mt-3" role="alert">
                                            <?php echo $error_message; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-footer text-center">
                                    <div class="small"><a href="login.php">¿Ya tienes una cuenta? Inicia sesión</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="assets/js/scripts.js"></script>
    <script>
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    </script>
</body>
</html>