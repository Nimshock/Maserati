<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once 'config/config.php';

    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    $query = "SELECT id, contrasena FROM usuarios WHERE usuario = ? AND role != 'admin'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        if (password_verify($contrasena, $hashed_password)) {
            $_SESSION['loggedin'] = true;
            $_SESSION['id'] = $id;
            $_SESSION['usuario'] = $usuario;
            header("location: index.php");
            exit;
        } else {
            $error_message = "Usuario o contraseña incorrectos";
        }
    } else {
        $error_message = "Usuario o contraseña incorrectos";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Inicio de sesión Maserati" />
    <meta name="author" content="Maserati Web" />
    <link rel="icon" href="assets/images/ico/logoMaseratiDorado.ico" type="image/x-icon">
    <title>Inicio de sesión - Maserati</title>
    <link href="assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>

    <style>
        :root {
            --maserati-blue: #0A246A;
            --maserati-card-bg: #1A1D24; 
            --maserati-input-bg: #2C2F36;
            --maserati-text-primary: #FFFFFF;
            --maserati-text-secondary: #adb5bd;
            --maserati-yellow-focus: #FFD700;
            --maserati-yellow-focus-rgb: 255, 215, 0; 
            --maserati-border-color-rgba: rgba(255, 255, 255, 0.15);
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: url('assets/images/login-images/backgroundLoginMaserati_user_2.jpg') no-repeat center center fixed;
            background-size: cover;
            color: var(--maserati-text-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            padding: 1rem;
        }

        #layoutAuthentication {
            width: 100%;
            position: relative; 
            /* z-index: 1; ya no es estrictamente necesario sin el ::before con z-index: 0 */
        }
        
        .card {
            background-color: var(--maserati-card-bg);
            border: 1px solid var(--maserati-border-color-rgba);
            border-radius: 0.5rem; 
            box-shadow: 0 0.25rem 1rem rgba(0,0,0,0.3); 
        }

        .card-header {
            background-color: transparent;
            border-bottom: 1px solid var(--maserati-border-color-rgba);
            padding-top: 2rem;
            padding-bottom: 1rem;
            text-align: center;
        }

        .logotipoMaserati {
            width: 90px;
            height: auto;
            margin-bottom: 1rem;
        }

        .card-header h3 {
            color: var(--maserati-text-primary);
            font-weight: 300;
            font-size: 1.75rem;
            margin-top: 0;
            margin-bottom: 0;
        }
        
        .admin-icon {
            position: absolute;
            top: 15px;
            right: 15px;
            background-color: rgba(255,255,255,0.05);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: var(--maserati-text-secondary);
            text-decoration: none;
            transition: background-color 0.2s ease, color 0.2s ease;
        }

        .admin-icon:hover {
            background-color: rgba(255,255,255,0.1);
            color: var(--maserati-text-primary);
        }

        .card-body {
            padding: 2rem;
        }

        .form-floating label {
            color: var(--maserati-text-secondary);
        }

        .form-control {
            background-color: var(--maserati-input-bg);
            border: 1px solid var(--maserati-border-color-rgba);
            color: var(--maserati-text-primary);
            border-radius: 0.375rem;
        }
        .form-control:focus {
            background-color: var(--maserati-input-bg);
            border-color: var(--maserati-yellow-focus);
            box-shadow: 0 0 0 0.25rem rgba(var(--maserati-yellow-focus-rgb), 0.25); 
            color: var(--maserati-text-primary);
        }
        
        .form-control::placeholder { color: var(--maserati-text-secondary); opacity: 1; }
        .form-control:-ms-input-placeholder { color: var(--maserati-text-secondary); }
        .form-control::-ms-input-placeholder { color: var(--maserati-text-secondary); }

        .btn-primary {
            background-color: var(--maserati-blue);
            border-color: var(--maserati-blue);
            padding: 0.65rem 1.25rem;
            font-weight: 500;
            width: 100%;
            border-radius: 0.375rem;
            transition: background-color 0.2s ease, border-color 0.2s ease;
        }

        .btn-primary:hover, .btn-primary:focus {
            background-color: #08205A; 
            border-color: #08205A;
            box-shadow: 0 0 0 0.25rem rgba(var(--maserati-blue), 0.25);
        }
        
        .card-footer {
            background-color: transparent;
            border-top: 1px solid var(--maserati-border-color-rgba);
            padding-top: 1.5rem;
            padding-bottom: 1.5rem;
        }

        .card-footer .small a {
            color: var(--maserati-text-secondary);
            text-decoration: none;
        }

        .card-footer .small a:hover {
            color: var(--maserati-text-primary);
            text-decoration: underline;
        }
        
        .alert {
            border-radius: 0.375rem;
            font-size: 0.9em;
            padding: 0.8rem 1rem;
        }
        .alert-success {
            background-color: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.3);
            color: #e2f0e6; 
        }
        .alert-danger {
            background-color: rgba(220, 53, 69, 0.2);
            border: 1px solid rgba(220, 53, 69, 0.3);
            color: #f8d7da;
        }
    </style>
</head>
<body>
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5 col-md-7 col-sm-10">
                            <div class="card my-5">
                                <div class="card-header">
                                    <img src="assets/images/logos-image/logoMaserati.png" alt="Logotipo Maserati" class="logotipoMaserati">
                                    <h3>Inicio de sesión</h3>
                                    <a href="login_admin.php" class="admin-icon" title="Acceso Administrador">
                                        <i class="fas fa-user-cog"></i>
                                    </a>
                                </div>
                                <div class="card-body">
                                    <form method="POST" action="login.php">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="usuario" name="usuario" type="text" placeholder="Usuario" required />
                                            <label for="usuario">Usuario</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="contrasena" name="contrasena" type="password" placeholder="Contraseña" required />
                                            <label for="contrasena">Contraseña</label>
                                        </div>
                                        <div class="mt-4 mb-0">
                                            <button class="btn btn-primary" type="submit">Iniciar sesión</button>
                                        </div>
                                        <?php if (isset($_GET['registered']) && $_GET['registered'] == 'true') : ?>
                                            <div class="alert alert-success mt-3" role="alert">
                                                ¡Cuenta creada exitosamente! Ahora puedes iniciar sesión.
                                            </div>
                                        <?php elseif (isset($error_message)) : ?>
                                            <div class="alert alert-danger mt-3" role="alert">
                                                <?php echo $error_message; ?>
                                            </div>
                                        <?php endif; ?>
                                    </form>
                                </div>
                                <div class="card-footer text-center">
                                    <div class="small"><a href="register.php">¿Es tu primera vez? ¡Regístrate!</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>