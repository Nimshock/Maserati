<?php
session_start();


if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("location: ../login_admin.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';


if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: reservas_admin.php");
    exit;
}

$reserva_id = $_GET['id'];

$sql = "DELETE FROM reservas WHERE id = ?";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $reserva_id);
    
    if ($stmt->execute()) {
        header("location: reservas_admin.php?delete=success");
    } else {
        echo "Error al intentar borrar la reserva.";
    }
    $stmt->close();
}
$conn->close();
?>