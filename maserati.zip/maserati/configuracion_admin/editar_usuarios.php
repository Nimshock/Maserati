<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("location: ../login_admin.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

$error = '';
$success = '';
$usuario_id = null;


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_details'])) {
    $usuario_id = $_POST['id'];
    $usuario_nombre = $_POST['usuario'];
    $usuario_role = $_POST['role'];
    $usuario_documentado = $_POST['documentado'];

    $stmt = $conn->prepare("UPDATE usuarios SET usuario = ?, role = ?, documentado = ? WHERE id = ?");
    $stmt->bind_param("ssii", $usuario_nombre, $usuario_role, $usuario_documentado, $usuario_id);

    if ($stmt->execute()) {
        $success = "¡Datos del usuario actualizados con éxito!";
    } else {
        $error = "Error al actualizar los datos del usuario.";
    }
    $stmt->close();
}


elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $usuario_id = $_POST['id'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password === $confirm_password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("UPDATE usuarios SET contrasena = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $usuario_id);

        if ($stmt->execute()) {
            $success = "¡Contraseña del usuario actualizada con éxito!";
        } else {
            $error = "Error al actualizar la contraseña.";
        }
        $stmt->close();
    } else {
        $error = "Las contraseñas no coinciden.";
    }
}


if (isset($_GET['id'])) {
    $usuario_id = $_GET['id'];
} elseif (isset($_POST['id'])) {
    $usuario_id = $_POST['id'];
} else {
    header("location: usuarios_admin.php");
    exit;
}


$stmt_select = $conn->prepare("SELECT usuario, role, documentado FROM usuarios WHERE id = ?");
$stmt_select->bind_param("i", $usuario_id);
$stmt_select->execute();
$result = $stmt_select->get_result();

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();
    $usuario_nombre = $user['usuario'];
    $usuario_role = $user['role'];
    $usuario_documentado = $user['documentado'];
} else {
    $error = "No se encontró el usuario.";
}
$stmt_select->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Editar Usuario - Admin</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Editar Usuario: <?php echo htmlspecialchars($usuario_nombre); ?></h2>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger mt-3"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (!empty($success)): ?>
            <div class="alert alert-success mt-3"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if ($result->num_rows == 1):?>
        
        <div class="card mt-4">
            <div class="card-header">Detalles del Usuario</div>
            <div class="card-body">
                <form method="post" action="editar_usuarios.php">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($usuario_id); ?>">
                    <div class="form-group">
                        <label for="usuario">Usuario:</label>
                        <input type="text" class="form-control" id="usuario" name="usuario" value="<?php echo htmlspecialchars($usuario_nombre); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Rol:</label>
                        <select class="form-control" id="role" name="role">
                            <option value="Usuario" <?php echo ($usuario_role == 'Usuario') ? 'selected' : ''; ?>>Usuario</option>
                            <option value="admin" <?php echo ($usuario_role == 'admin') ? 'selected' : ''; ?>>Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="documentado">Documentado (1 = Sí, 0 = No):</label>
                        <input type="number" class="form-control" id="documentado" name="documentado" value="<?php echo htmlspecialchars($usuario_documentado); ?>" required min="0" max="1">
                    </div>
                    <button type="submit" name="update_details" class="btn btn-primary">Guardar Datos</button>
                </form>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header">Cambiar Contraseña</div>
            <div class="card-body">
                <form method="post" action="editar_usuarios.php">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($usuario_id); ?>">
                    <div class="form-group">
                        <label for="password">Nueva Contraseña:</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Dejar en blanco para no cambiar" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirmar Nueva Contraseña:</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Repetir contraseña" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-warning">Actualizar Contraseña</button>
                </form>
            </div>
        </div>
        
        <a href="usuarios_admin.php" class="btn btn-secondary mt-4">Volver al Listado</a>
        <?php endif; ?>
    </div>
</body>
</html>