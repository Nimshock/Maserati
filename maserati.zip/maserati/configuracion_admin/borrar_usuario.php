<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("location: ../login_admin.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $usuario_id = $_GET['id'];

    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $query = "DELETE FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $usuario_id);

    if ($stmt->execute()) {
        header("location: usuarios_admin.php");
    } else {
        echo "Error al intentar borrar el usuario.";
    }

    $stmt->close();
    $conn->close();
} else {
    header("location: usuarios_admin.php");
}
?>