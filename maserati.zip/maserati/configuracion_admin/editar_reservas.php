<?php
session_start();


if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("location: ../login_admin.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reserva_id'])) {
    $reserva_id = $_POST['reserva_id'];
    $estado_reserva = $_POST['estado_reserva'];

    $sql = "UPDATE reservas SET estado_reserva = ? WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("si", $estado_reserva, $reserva_id);
        if ($stmt->execute()) {
            header("location: reservas_admin.php?update=success");
            exit;
        } else {
            $error = "Error al actualizar la reserva.";
        }
        $stmt->close();
    }
}


if (!isset($_GET['id'])) {
    header("location: reservas_admin.php");
    exit;
}
$reserva_id = $_GET['id'];
$query = "SELECT * FROM reservas WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $reserva_id);
$stmt->execute();
$result = $stmt->get_result();
$reserva = $result->fetch_assoc();
$stmt->close();
$conn->close();

if (!$reserva) {
    echo "Reserva no encontrada.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <title>Editar Reserva - Admin</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Editar Estado de la Reserva #<?php echo htmlspecialchars($reserva['id']); ?></h2>
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="POST" action="editar_reservas.php">
            <input type="hidden" name="reserva_id" value="<?php echo $reserva['id']; ?>">
            <div class="form-group">
                <label for="estado_reserva">Estado</label>
                <select name="estado_reserva" id="estado_reserva" class="form-control">
                    <option value="Activa" <?php echo ($reserva['estado_reserva'] == 'Activa') ? 'selected' : ''; ?>>Activa</option>
                    <option value="Completada" <?php echo ($reserva['estado_reserva'] == 'Completada') ? 'selected' : ''; ?>>Completada</option>
                    <option value="Cancelada" <?php echo ($reserva['estado_reserva'] == 'Cancelada') ? 'selected' : ''; ?>>Cancelada</option>
                </select>
            </div>
            <br>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="reservas_admin.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>