<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("location: ../login_admin.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: documentacion_admin.php");
    exit;
}

$doc_id = $_GET['id'];

$conn->begin_transaction();

try {

    $query_get_user = "SELECT usuario_id FROM documentacion WHERE id = ?";
    $stmt_get_user = $conn->prepare($query_get_user);
    $stmt_get_user->bind_param("i", $doc_id);
    $stmt_get_user->execute();
    $result_user = $stmt_get_user->get_result();

    if ($result_user->num_rows === 0) {
        throw new Exception("No se encontró la documentación.");
    }

    $user_row = $result_user->fetch_assoc();
    $usuario_id_to_update = $user_row['usuario_id'];
    $stmt_get_user->close();


    $query_delete = "DELETE FROM documentacion WHERE id = ?";
    $stmt_delete = $conn->prepare($query_delete);
    $stmt_delete->bind_param("i", $doc_id);
    $stmt_delete->execute();
    $stmt_delete->close();


    $query_update = "UPDATE usuarios SET documentado = 0 WHERE id = ?";
    $stmt_update = $conn->prepare($query_update);
    $stmt_update->bind_param("i", $usuario_id_to_update);
    $stmt_update->execute();
    $stmt_update->close();


    $conn->commit();
    header("location: documentacion_admin.php?delete=success");

} catch (Exception $e) {
    $conn->rollback();
    echo "Error: " . $e->getMessage();
}

$conn->close();
?>