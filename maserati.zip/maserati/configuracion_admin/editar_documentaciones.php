<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("location: ../login_admin.php");
    exit;
}

require_once __DIR__ . '/../config/config.php';

// --- INICIO DE LA CORRECCIÓN ---

// 1. OBTENER EL ID (DE POST o GET, de forma segura)
// Si la página se recarga por un POST, toma el id de ahí. Si se carga por primera vez, lo toma del GET.
$doc_id = $_POST['id'] ?? $_GET['id'] ?? null;

if (!$doc_id) {
    // Si no hay ID de ninguna forma, no podemos continuar.
    header("location: documentacion_admin.php");
    exit;
}

$error = '';
$success = '';

// 2. PROCESAR EL FORMULARIO (SOLO SI ES UNA PETICIÓN POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $apellido1 = $_POST['apellido1'];
    $apellido2 = $_POST['apellido2'];
    $edad = $_POST['edad'];

    // Validación de edad
    if ($edad < 18) {
        $error = "La edad no puede ser menor de 18 años.";
    } else {
        // Si la edad es correcta, se procede con la actualización
        $sql = "UPDATE documentacion SET nombre = ?, apellido1 = ?, apellido2 = ?, edad = ? WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sssii", $nombre, $apellido1, $apellido2, $edad, $doc_id);
            
            if ($stmt->execute()) {
                $success = "¡Documentación actualizada con éxito!";
            } else {
                $error = "Error al actualizar la documentación.";
            }
            $stmt->close();
        }
    }
}

// 3. OBTENER SIEMPRE LOS DATOS MÁS RECIENTES PARA MOSTRAR EN EL FORMULARIO
// Esta consulta se ejecuta siempre, para asegurar que el formulario tenga los datos correctos
// tanto al cargar la página por primera vez como después de un intento de actualización.
$query = "SELECT nombre, apellido1, apellido2, edad FROM documentacion WHERE id = ?";
if ($stmt = $conn->prepare($query)) {
    $stmt->bind_param("i", $doc_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $doc = $result->fetch_assoc();
        // Si no estamos procesando un POST con error, usamos los datos de la BBDD.
        // Si hay un error, dejamos los datos que el usuario acaba de introducir en el formulario.
        if ($_SERVER["REQUEST_METHOD"] != "POST" || !empty($success)) {
            $nombre = $doc['nombre'];
            $apellido1 = $doc['apellido1'];
            $apellido2 = $doc['apellido2'];
            $edad = $doc['edad'];
        }
    } else {
        // Este error solo debería aparecer si el ID es incorrecto.
        $error = "No se encontró la documentación con ese ID.";
        $doc_id = ''; // Vaciamos el ID si no se encuentra
    }
    $stmt->close();
}
$conn->close();

// --- FIN DE LA CORRECCIÓN ---
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../assets/images/logos-image/logoMaseratiDorado.png">
    <title>Editar Documentación - Admin</title>
    <link href="../assets/css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h2>Editar Documentación #<?php echo htmlspecialchars($doc_id); ?></h2>
            </div>
            <div class="card-body">
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" action="editar_documentaciones.php">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($doc_id); ?>">
                    
                    <div class="form-group mb-3">
                        <label for="nombre">Nombre</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="apellido1">Primer Apellido</label>
                        <input type="text" class="form-control" id="apellido1" name="apellido1" value="<?php echo htmlspecialchars($apellido1); ?>" required>
                    </div>

                    <div class="form-group mb-3">
                        <label for="apellido2">Segundo Apellido</label>
                        <input type="text" class="form-control" id="apellido2" name="apellido2" value="<?php echo htmlspecialchars($apellido2); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="edad">Edad</label>
                        <input type="number" class="form-control" id="edad" name="edad" value="<?php echo htmlspecialchars($edad); ?>" required min="18">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    <a href="documentacion_admin.php" class="btn btn-secondary">Volver al Listado</a>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>