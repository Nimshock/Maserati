<?php
session_start();

$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

if (isset($_GET['error']) && $_GET['error'] === 'documentado') {
    echo '<div id="error-alert" class="alert alert-danger" role="alert" style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); z-index: 9999;">';
    echo '¡Tienes que hacer tu documentación Maserati para acceder a ese sitio!';
    echo '</div>';
}


require_once __DIR__ . '/config/config.php';


$usuario_id = $_SESSION['id'];


$query = "SELECT documentado FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

$documentado = 0; 
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $documentado = $row['documentado'];
}
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-menu-color="light" data-topbar-color="dark">

<?php include("head.php") ?>

<body>

    <?php include("header.php") ?>

    <?php include("inicio.php") ?>

    <?php include("caracteristicasCoches.php") ?>

    <?php 
        include("modelosCoches.php") 
    ?>

    <?php include("sobreNosotros.php") ?>

    <?php include("clientes.php") ?>

    <?php include("precios.php") ?>

    <?php include("contactos.php") ?>

    <?php include("footer.php") ?>

    <?php include("scripts.php") ?>

</body>
</html>